

*Most textures are tileable, a cube or simple model was provided with each texture type (aligned Uvs)

*textures are 16x16 pixels each

*Some cubes will only display correctly with 32x32 "texture sets" (to avoid using multiple spread textures that do not entirely fit the right way)

all textures in this package are free to use, commercial included, all done by gamescipline brand,
(if using, please give credits :], if you contributed to the cause or bought the assets, I am for ever grateful), use them at your own imagination, they can also be altered in any way you like.

for any questions, send email to gamescipline@gmail.com
 or twitter @gamescipline